package com.example.favorite_songs_web

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
