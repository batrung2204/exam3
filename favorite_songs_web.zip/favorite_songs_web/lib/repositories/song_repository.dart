import 'package:flutter/foundation.dart';
import '../models/song.dart';

class SongRepository extends ChangeNotifier {
  List<Song> _songs = [];

  List<Song> get songs => _songs;

  void addSong(Song song) {
    _songs.add(song);
    notifyListeners();
  }

  void updateSong(int index, Song song) {
    if (index >= 0 && index < _songs.length) {
      _songs[index] = song;
      notifyListeners();
    }
  }

  void deleteSong(int index) {
    if (index >= 0 && index < _songs.length) {
      _songs.removeAt(index);
      notifyListeners();
    }
  }
}
