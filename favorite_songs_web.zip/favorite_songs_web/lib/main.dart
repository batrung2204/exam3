import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'models/song.dart';
import 'repositories/song_repository.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => SongRepository(),
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Favorite Songs',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: SongListScreen(),
    );
  }
}

class SongListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final songRepo = Provider.of<SongRepository>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Favorite Songs'),
      ),
      body: ListView.builder(
        itemCount: songRepo.songs.length,
        itemBuilder: (context, index) {
          final song = songRepo.songs[index];
          return ListTile(
            title: Text(song.title),
            subtitle: Text('${song.artist} (${song.year})'),
            trailing: IconButton(
              icon: Icon(Icons.delete),
              onPressed: () {
                songRepo.deleteSong(index);
              },
            ),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => SongEditScreen(index: index),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => SongEditScreen(index: -1),
            ),
          );
        },
      ),
    );
  }
}

class SongEditScreen extends StatefulWidget {
  final int index;

  SongEditScreen({required this.index});

  @override
  _SongEditScreenState createState() => _SongEditScreenState();
}

class _SongEditScreenState extends State<SongEditScreen> {
  final _titleController = TextEditingController();
  final _artistController = TextEditingController();
  final _yearController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.index >= 0) {
      final song = Provider.of<SongRepository>(context, listen: false).songs[widget.index];
      _titleController.text = song.title;
      _artistController.text = song.artist;
      _yearController.text = song.year.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    final songRepo = Provider.of<SongRepository>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.index >= 0 ? 'Edit Song' : 'Add Song'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            TextField(
              controller: _titleController,
              decoration: InputDecoration(labelText: 'Title'),
            ),
            TextField(
              controller: _artistController,
              decoration: InputDecoration(labelText: 'Artist'),
            ),
            TextField(
              controller: _yearController,
              decoration: InputDecoration(labelText: 'Year'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                final title = _titleController.text;
                final artist = _artistController.text;
                final year = int.tryParse(_yearController.text) ?? 0;

                if (widget.index >= 0) {
                  songRepo.updateSong(widget.index, Song(title, artist, year));
                } else {
                  songRepo.addSong(Song(title, artist, year));
                }
                Navigator.pop(context);
              },
              child: Text(widget.index >= 0 ? 'Update' : 'Add'),
            ),
          ],
        ),
      ),
    );
  }
}
