class Song {
  String title;
  String artist;
  int year;

  Song(this.title, this.artist, this.year);

  factory Song.fromJson(Map<String, dynamic> json) {
    return Song(
      json['title'],
      json['artist'],
      json['year'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'artist': artist,
      'year': year,
    };
  }
}
